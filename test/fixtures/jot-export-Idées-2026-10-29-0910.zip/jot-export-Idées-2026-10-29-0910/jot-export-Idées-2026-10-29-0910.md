<!-- jot:export v=1 date=2026-10-29T14:10:00Z -->
Stats: 1 jot across 1 category

<!-- jot:category name="Ideas" id="6F1C2B9A-3D4E-4F5A-8B7C-1A2B3C4D5E6F" -->
- 10/29/26, 9:10 AM A reading nook under the stairs ![0C1D2E3F-4A5B-4C6D-8E7F-901A2B3C4D5E.png](media/0C1D2E3F-4A5B-4C6D-8E7F-901A2B3C4D5E.png)
<!-- /jot:category -->